
package empleado;

import java.time.LocalDate;

public class Persona {
    
    private String nombre;
    private String apellido;
    private LocalDate fechaNacimiento;
    private String tipoDocumento;
    private String telefono;
    private String email;
    
    public Persona(String nombre, String apellido, LocalDate fechaNacimiento, String tipoDocumento, String telefono, String email) {
        this.nombre=nombre;
        this.apellido=apellido;
        this.fechaNacimiento=fechaNacimiento;
        this.tipoDocumento=tipoDocumento;
        this.telefono=telefono;
        this.email=email;
    }
    public String getNombre() {
        return nombre;
    }
    
    public String getApellido() {
        return apellido;
    }
    
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }
    
    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", fechaNacimiento=" + fechaNacimiento +
                ", tipoDocumento='" + tipoDocumento + '\'' +
                ", telefono='" + telefono + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
