
package empleado;

import empleado.Empleado;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        Queue<Empleado> colaEmpleados = new LinkedList<>();
        
        colaEmpleados.offer(new Empleado("Mois�s", "101"));
        colaEmpleados.offer(new Empleado("Lucio", "102"));
        colaEmpleados.offer(new Empleado("Andrea", "103"));
        colaEmpleados.offer(new Empleado("Facundo", "104"));
        
        System.out.println("Empleados en la cola:");
        for (Empleado empleado : colaEmpleados){
            System.out.println(empleado);
        }
        
        Empleado empleadoDesencolado = colaEmpleados.poll();
        System.out.println("\nEmpleado desencolado: " + empleadoDesencolado);
        
        System.out.println("\nEmpleados en la cola despu�s de desencolar:");
        for (Empleado empleado : colaEmpleados) {
            System.out.println(empleado);
        }
        
         Stack<Empleado> pilaEmpleados = new Stack<>();
        
        pilaEmpleados.push(new Empleado("A", "105"));
        pilaEmpleados.push(new Empleado("B", "106"));
        pilaEmpleados.push(new Empleado("C", "107"));
        
        System.out.println("\nEmpleados en la pila:");
        for (Empleado empleado : pilaEmpleados) {
             System.out.println(empleado);
             
        }
        
        Empleado empleadoDesapilado = pilaEmpleados.pop();
        System.out.println("\nEmpleado desapilado: " + empleadoDesapilado);
        
        System.out.println("\nEmpleados en la pila despu�s de desapilar:");
        for (Empleado empleado : pilaEmpleados) {
            System.out.println(empleado);
        }       
    }  
}
